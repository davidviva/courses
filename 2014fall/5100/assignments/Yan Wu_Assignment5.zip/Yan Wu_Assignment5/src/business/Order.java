/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author wuyan
 */
public class Order {
    private int orderId;
    private static int orderCount;
    private ArrayList<OrderItem> orderItemList;
    private Date timestamp;
    private int totalAmount;
    
    public Order() {
        orderCount++;
        orderId = orderCount;
        orderItemList = new ArrayList<OrderItem>();
        totalAmount = 0;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public int getTotalAmount() {
        return totalAmount;
    }
    
    public int computeTotalAmount(ArrayList<OrderItem> orderItemList) {
        for(OrderItem oi: orderItemList)
        {
            totalAmount += oi.getAmount();
        }
        return totalAmount;
    }
    
    public int getOrderId() {
        return orderId;
    }

    public static int getOrderCount() {
        return orderCount;
    }

    public ArrayList<OrderItem> getOrderItemList() {
        return orderItemList;
    }

    public void setOrderItemList(ArrayList<OrderItem> orderItemList) {
        this.orderItemList = orderItemList;
    }
    
    public OrderItem addOrderItem(Product product, int price, int quantity) {
        OrderItem orderItem = new OrderItem(product, price, quantity);
        orderItemList.add(orderItem);
        return orderItem;
    }
    
    public void removeOrderItem(OrderItem orderItem) {
        orderItemList.remove(orderItem);
    }

    @Override
    public String toString() {
        return String.valueOf(orderId);
    }
    
}
