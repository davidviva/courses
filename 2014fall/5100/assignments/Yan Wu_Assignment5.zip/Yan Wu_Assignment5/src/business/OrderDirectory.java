/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class OrderDirectory {
    private ArrayList<Order> orderDirectory;

    public OrderDirectory() {
        orderDirectory = new ArrayList<Order>();
    }

    public ArrayList<Order> getOrderDirectory() {
        return orderDirectory;
    }

    public void setOrderDirectory(ArrayList<Order> orderDirectory) {
        this.orderDirectory = orderDirectory;
    }
       
    public Order addOrder() {
        Order o = new Order();
        orderDirectory.add(o);
        return o;
    }
    
   /* public void removeOrder(Order order) {
        orderDirectory.remove(order);
    }
    
    public Order searchOrder(String keyword) {
        for(Order o: orderDirectory) {
            if(keyword.equals(String.valueOf(o.getOrderId()))) {
                return o;
            }
        }
        return null;
    } */
    
        public void addOrder(Order order)
    {
        orderDirectory.add(order);
    }
    
    public void removeOrder(Order order){
        orderDirectory.remove(order);
    }
}
