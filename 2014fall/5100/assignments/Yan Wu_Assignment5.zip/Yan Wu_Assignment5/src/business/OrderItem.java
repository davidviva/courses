/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author wuyan
 */
public class OrderItem {
    private Product product;
    private int salesPrice;
    private int quantity;
    private int amount = 0;
    
    // constructor
    public OrderItem(Product product, int salesPrice, int quantity) {
        this.product = product;
        this.salesPrice = salesPrice;
        this.quantity = quantity;
        amount = this.salesPrice * this.quantity;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getSalesPrice() {
        return salesPrice;
    }

    public void setSalesPrice(int salesPrice) {
        this.salesPrice = salesPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return product.getProductName();
    }
    
    
}
