/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author wuyan
 */
public class Supplier {
    private String supplyName ;
    private String password = "admin" ;
    private ProductCatalog productCatalog ;
    
    public Supplier()
    {
        productCatalog = new ProductCatalog() ;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    
    public String getSupplyName() {
        return supplyName;
    }

    public void setSupplyName(String supplyName) {
        this.supplyName = supplyName;
    }

    public ProductCatalog getProductCatalog() {
        return productCatalog; 
    }

    @Override
    public String toString() {
        return supplyName ;
    }
    
}
