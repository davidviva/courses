/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author wuyan
 */
public class ConfigureBusiness {
   public static Business Initialize(){
       Business business = Business.getInstance();
       Employee e = business.getEmployeeDirectory().addEmployee();
       e.setFirstName("Yan");
       e.setLastName("Wu");
       e.setOrganisation("NEU");
       UserAccount u = business.getUserAccountDirectory().addUserAccount();
       u.setPerson(e);
       u.setRole(UserAccount.ADMIN);
       u.setStatus("Active");
       u.setUserName("admin");
       u.setPassWord("admin");
       return business;
   }   
}
