/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author wuyan
 */
public class Employee extends Person{
    private static int count = 0;
    private int empId;
    private String organisation;
    
    public Employee(){
        count++;
        empId = count;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getOrganisation() {
        return organisation;
    }

    public void setOrganisation(String organisation) {
        this.organisation = organisation;
    }
    
    public String toString(){
        return super.getFirstName();
    }
}
