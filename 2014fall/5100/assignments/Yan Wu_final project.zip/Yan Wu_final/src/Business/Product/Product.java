/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Product;

import Business.Vaccine.Vaccine;
import java.util.Date;

/**
 *
 * @author wuyan
 */
public class Product {
    private static int productCount = 0;
    private int productId;
    private Vaccine vaccine;
    private int price = 0;
    private int quantity = 0;
    private Date productionDate;
    private int durabilityPeriod;
    private String manufacturer;
    
    public Product() {
        productCount++;
        productId = productCount;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Vaccine getVaccine() {
        return vaccine;
    }

    public void setVaccine(Vaccine vaccine) {
        this.vaccine = vaccine;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Date getProductionDate() {
        return productionDate;
    }

    public void setProductionDate(Date productionDate) {
        this.productionDate = productionDate;
    }

    public int getDurabilityPeriod() {
        return durabilityPeriod;
    }

    public void setDurabilityPeriod(int durabilityPeriod) {
        this.durabilityPeriod = durabilityPeriod;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    @Override
    public String toString() {
        return String.valueOf(productId);
    }   
    
}
