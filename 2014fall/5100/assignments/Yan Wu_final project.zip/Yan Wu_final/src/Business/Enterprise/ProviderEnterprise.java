/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Inventory.Inventory;
import Business.Order.OrderCatalog;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class ProviderEnterprise extends Enterprise{
    private ProviderEnterpriseType providerEnterpriseType;
    private OrderCatalog orderCatalog;
    private Inventory inventory;
    private OrderCatalog pendingCatalog;
    private OrderCatalog purchaseHistory;
    private String address;
     
    public ProviderEnterprise(String name, ProviderEnterpriseType type) {
        super(name, Enterprise.EnterpriseType.Provider);
        this.providerEnterpriseType = type;
        orderCatalog = new OrderCatalog();
        inventory = new Inventory();
        pendingCatalog = new OrderCatalog();
        purchaseHistory = new OrderCatalog();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public OrderCatalog getPendingCatalog() {
        return pendingCatalog;
    }

    public void setPendingCatalog(OrderCatalog pendingCatalog) {
        this.pendingCatalog = pendingCatalog;
    }

    public OrderCatalog getPurchaseHistory() {
        return purchaseHistory;
    }

    public void setPurchaseHistory(OrderCatalog purchaseHistory) {
        this.purchaseHistory = purchaseHistory;
    }
    
    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
    
    public OrderCatalog getOrderCatalog() {
        return orderCatalog;
    }

    public void setOrderCatalog(OrderCatalog orderCatalog) {
        this.orderCatalog = orderCatalog;
    }
    
    
    public enum ProviderEnterpriseType{
        Clinic("Clinic"),
        Pharmacy("Pharmacy"),
        Hos("Hospital");
         
        private String value;

        private ProviderEnterpriseType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    public ProviderEnterpriseType getProviderEnterpriseType() {
        return providerEnterpriseType;
    }   

    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    } 
    
    @Override
    public String toString() {
        return super.getName();
    }
    
    
}
