/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.Role;
import Business.Vaccine.VaccineCatalog;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class CDCEnterprise extends Enterprise {
    
    ArrayList<PHDEnterprise> PHDList;
    VaccineCatalog vaccineCatalog;
    private int account = 10000000;
    
    public CDCEnterprise(String name) {
        super(name, EnterpriseType.CDC);
        PHDList = new ArrayList<>();
        vaccineCatalog = new VaccineCatalog();
    }

    public int getAccount() {
        return account;
    }

    public void setAccount(int account) {
        this.account = account;
    }

    public VaccineCatalog getVaccineCatalog() {
        return vaccineCatalog;
    }

    public void setVaccineCatalog(VaccineCatalog vaccineCatalog) {
        this.vaccineCatalog = vaccineCatalog;
    }
 
    public ArrayList<PHDEnterprise> getPHDList() {
        return PHDList;
    }

    public void setPHDList(ArrayList<PHDEnterprise> PHDList) {
        this.PHDList = PHDList;
    }
    
    public PHDEnterprise createAndAddEnterprise(String state, String name){
        PHDEnterprise phd = new PHDEnterprise(state, name);
        PHDList.add(phd);
        return phd;
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    }
}
