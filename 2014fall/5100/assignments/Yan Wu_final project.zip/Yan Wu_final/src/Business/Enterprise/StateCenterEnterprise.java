/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Inventory.Inventory;
import Business.Order.OrderCatalog;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class StateCenterEnterprise extends Enterprise {
    String state;
    OrderCatalog orderCatalog;
    Inventory inventory;
    
    public StateCenterEnterprise(String name, String state) {
        super(name, Enterprise.EnterpriseType.StateCenter);
        this.state = state;
        orderCatalog = new OrderCatalog();
        inventory = new Inventory();
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public OrderCatalog getOrderCatalog() {
        return orderCatalog;
    }

    public void setOrderCatalog(OrderCatalog orderCatalog) {
        this.orderCatalog = orderCatalog;
    }
    
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    }

    @Override
    public String toString() {
        return state;
    }

}
