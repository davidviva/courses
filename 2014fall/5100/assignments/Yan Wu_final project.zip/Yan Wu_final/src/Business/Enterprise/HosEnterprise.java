/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class HosEnterprise extends ProviderEnterprise {
    ArrayList<ClinicEnterprise> clinicList;
    
    public HosEnterprise(String name) {
        super(name, ProviderEnterpriseType.Hos);
        clinicList = new ArrayList<>();
    }
    
    public ArrayList<ClinicEnterprise> getClinicList() {
        return clinicList;
    }

    public void setClinicList(ArrayList<ClinicEnterprise> clinicList) {
        this.clinicList = clinicList;
    }
    
    public ClinicEnterprise createAndAddClinic(String name){
        ClinicEnterprise c = new ClinicEnterprise(name);
        clinicList.add(c);
        return c;
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    } 
    
    @Override
    public String toString() {
        return super.getName();
    }
}
