/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Inventory.Inventory;
import Business.Order.OrderCatalog;
import Business.Product.ProductCatalog;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class ManufacturerEnterprise extends Enterprise {
    private ProductCatalog productCatalog;
    private ProductCatalog productionLog;
    private Inventory inventory;
    private OrderCatalog stateorderCatalog;
    
    public ManufacturerEnterprise(String name) {
        super(name, EnterpriseType.Manufacturer);
        productCatalog = new ProductCatalog();
        productionLog = new ProductCatalog();
        inventory = new Inventory();
        stateorderCatalog = new OrderCatalog();
    }

    public OrderCatalog getStateorderCatalog() {
        return stateorderCatalog;
    }

    public void setStateorderCatalog(OrderCatalog stateorderCatalog) {
        this.stateorderCatalog = stateorderCatalog;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
    
    public ProductCatalog getProductionLog() {
        return productionLog;
    }

    public void setProductionLog(ProductCatalog productionLog) {
        this.productionLog = productionLog;
    }
    
    public ProductCatalog getProductCatalog() {
        return productCatalog;
    }

    public void setProductCatalog(ProductCatalog productCatalog) {
        this.productCatalog = productCatalog;
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    }
}
