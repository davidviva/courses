/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Order.Order;
import Business.Order.OrderCatalog;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class PHDEnterprise extends Enterprise {
    private ArrayList<ProviderEnterprise> providerList;
    private OrderCatalog orderCatalog;
    private OrderCatalog providerOrderHistory;
    private Order stateOrder;
    private OrderCatalog stateOrderHistory;
    private String state;
    private int population;
    
    public PHDEnterprise(String state, String name) {
        super(name, EnterpriseType.PHD);
        this.state = state;
        providerList = new ArrayList<>();
        orderCatalog = new OrderCatalog();
        stateOrder = new Order();
        stateOrder.setProvider(state);
        stateOrderHistory = new OrderCatalog();
        providerOrderHistory = new OrderCatalog();
    }

    public OrderCatalog getProviderOrderHistory() {
        return providerOrderHistory;
    }

    public void setProviderOrderHistory(OrderCatalog providerOrderHistory) {
        this.providerOrderHistory = providerOrderHistory;
    }

    public OrderCatalog getStateOrderHistory() {
        return stateOrderHistory;
    }

    public void setStateOrderHistory(OrderCatalog stateOrderHistory) {
        this.stateOrderHistory = stateOrderHistory;
    }
    
    public Order getStateOrder() {
        return stateOrder;
    }

    public void setStateOrder(Order stateOrder) {
        this.stateOrder = stateOrder;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public OrderCatalog getOrderCatalog() {
        return orderCatalog;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    
    public ArrayList<ProviderEnterprise> getProviderList() {
        return providerList;
    }

    public void setPHDList(ArrayList<ProviderEnterprise> providerList) {
        this.providerList = providerList;
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    }
    
    public ProviderEnterprise createAndAddEnterprise(String name, ProviderEnterprise.ProviderEnterpriseType type){
        ProviderEnterprise providerEnterprise = null;
        
        if(type == ProviderEnterprise.ProviderEnterpriseType.Hos){
            providerEnterprise = new HosEnterprise(name);
            providerList.add(providerEnterprise);
        }
        else if(type == ProviderEnterprise.ProviderEnterpriseType.Clinic){
            providerEnterprise = new ClinicEnterprise(name);
            providerList.add(providerEnterprise);
        }
        else{
            providerEnterprise = new PharmacyEnterprise(name);
            providerList.add(providerEnterprise);
        }
        return providerEnterprise;
    }
    

    @Override
    public String toString() {
        return state;
    }
       
}
