/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import Business.Order.OrderCatalog;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class DistributorEnterprise extends Enterprise {
    ArrayList<StateCenterEnterprise> stateCenterList;
    OrderCatalog stateorderCatalog;
    
    public DistributorEnterprise(String name) {
        super(name, EnterpriseType.Distributor);
        stateCenterList = new ArrayList<>();
        stateorderCatalog = new OrderCatalog();
    }

    public OrderCatalog getStateorderCatalog() {
        return stateorderCatalog;
    }

    public void setStateorderCatalog(OrderCatalog stateorderCatalog) {
        this.stateorderCatalog = stateorderCatalog;
    }

    public ArrayList<StateCenterEnterprise> getStateCenterList() {
        return stateCenterList;
    }

    public void setStateCenterList(ArrayList<StateCenterEnterprise> stateCenterList) {
        this.stateCenterList = stateCenterList;
    } 
    
    public StateCenterEnterprise createAndAddEnterprise(String state, String name){
        StateCenterEnterprise sc = new StateCenterEnterprise(state, name);
        stateCenterList.add(sc);
        return sc;
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    }
}
