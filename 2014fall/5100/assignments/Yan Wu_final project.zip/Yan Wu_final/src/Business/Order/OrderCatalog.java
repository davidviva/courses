/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Order;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class OrderCatalog {
    ArrayList<Order> orderList;
    
    public OrderCatalog(){
        orderList = new ArrayList<>();
    }

    public ArrayList<Order> getOrderList() {
        return orderList;
    }

    public void setOrderList(ArrayList<Order> orderList) {
        this.orderList = orderList;
    }
    
    public Order addOrder(Order o) {
        orderList.add(o);
        return o;
    }
    
    public void removeOrder(int id) {
        Order order = new Order();
        for(Order o: orderList){
            if(o.getOrderId() == id){
                order = o;
            }
        }
        orderList.remove(order);
    }
    
    public Order searchOrder(int id) {
        for(Order o : orderList) {
            if(o.getOrderId() == id) {
                return o;
            }
        }
        return null;
    }
}
