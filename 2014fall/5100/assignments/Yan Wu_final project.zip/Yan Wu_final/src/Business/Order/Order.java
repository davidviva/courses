/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Order;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author wuyan
 */
public class Order {
    ArrayList<OrderItem> orderItemList;
    private float totalCost = 0;
    private static int count = 0;
    private int orderId;
    private String provider;
    private int patientId;
    private Date timestamp;
    private String status;
    
    public Order(){
        orderItemList = new ArrayList<>();
        orderId = count++;
        status = "pending";
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public ArrayList<OrderItem> getOrderItemList() {
        return orderItemList;
    }

    public void setOrderItemList(ArrayList<OrderItem> orderItemList) {
        this.orderItemList = orderItemList;
    }

    public float getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(float totalCost) {
        this.totalCost = totalCost;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
    
    public OrderItem addOrderItem() {
        OrderItem oi = new OrderItem();
        orderItemList.add(oi);
        return oi;
    }
    
    public void removeOrderItem(OrderItem oi) {
        orderItemList.remove(oi);
    }
    
    public OrderItem searchOrderItem(String name) {
        for(OrderItem oi : orderItemList) {
            if(oi.getVaccine().equalsIgnoreCase(name)) {
                return oi;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return String.valueOf(orderId);
    }
}
