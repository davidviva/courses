/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Patient;

import Business.Diagnosis.DiagnosisHistory;

/**
 *
 * @author wuyan
 */
public class Patient {
    private String name;
    private int id;
    boolean insuranced;
    private DiagnosisHistory diagnosisHistory;
    
    public Patient(){
        diagnosisHistory = new DiagnosisHistory();
    }

    public boolean isInsuranced() {
        return insuranced;
    }

    public void setInsuranced(boolean insuranced) {
        this.insuranced = insuranced;
    }

    public DiagnosisHistory getDiagnosisHistory() {
        return diagnosisHistory;
    }

    public void setDiagnosisHistory(DiagnosisHistory diagnosisHistory) {
        this.diagnosisHistory = diagnosisHistory;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return name;
    }
}
