/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Patient;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class PatientCatalog {
    private ArrayList<Patient> patientList;

    // constructor
    public PatientCatalog() {    
        //this.accountList = accountList;
        patientList = new ArrayList<Patient>();
    }   

    //getter and setter
    public ArrayList<Patient> getPatientList() {
        return patientList;
    }

    public void setPatientList(ArrayList<Patient> accountList) {
        this.patientList = accountList;
    }
    
    //functionality   CRUD
    public Patient createPatient() {
        Patient a = new Patient();
        patientList.add(a);
        return a;
    }
    
    public void deletePatient(Patient a) {
        patientList.remove(a);
    }
           
    public Patient searchPatient(int Id) {
        for(Patient a:patientList)
        {
            if(a.getId() == Id)
            {
                return a;
            }
        }
        return null;
    }
}
