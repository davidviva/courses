/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Vaccine;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class VaccineCatalog {
    private ArrayList<Vaccine> vaccineList;
    
    public VaccineCatalog() {
        vaccineList = new ArrayList<>();
    }

    public ArrayList<Vaccine> getVaccineList() {
        return vaccineList;
    }
    
    public Vaccine addVaccine() {
        Vaccine v = new Vaccine();
        vaccineList.add(v);
        return v;
    }
    
    public void removeVaccine(Vaccine v) {
        vaccineList.remove(v);
    }
    
    public Vaccine searchVaccine(int id) {
        for(Vaccine v : vaccineList) {
            if(v.getVaccineId() == id) {
                return v;
            }
        }
        return null;
    }
}
