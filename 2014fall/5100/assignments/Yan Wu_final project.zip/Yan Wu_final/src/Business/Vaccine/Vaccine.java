/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Vaccine;

import Business.Disease.DiseaseCatalog;

/**
 *
 * @author wuyan
 */
public class Vaccine {
    private static int count = 0;
    private String vaccineName;
    private int vaccineId;
    private DiseaseCatalog cureDiseaseCatalog;

    
    public Vaccine() {
        count++;
        vaccineId = count;
        cureDiseaseCatalog = new DiseaseCatalog();
    }

    public DiseaseCatalog getCureDiseaseCatalog() {
        return cureDiseaseCatalog;
    }

    public void setCureDiseaseCatalog(DiseaseCatalog cureDiseaseCatalog) {
        this.cureDiseaseCatalog = cureDiseaseCatalog;
    }

    public String getVaccineName() {
        return vaccineName;
    }

    public void setVaccineName(String vaccineName) {
        this.vaccineName = vaccineName;
    }

    public int getVaccineId() {
        return vaccineId;
    }

    public void setVaccineId(int vaccineId) {
        this.vaccineId = vaccineId;
    }

    
    @Override
    public String toString() {
        return vaccineName;
    }
    
}
