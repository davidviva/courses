/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.CDCEnterprise;
import Business.Enterprise.ClinicEnterprise;
import Business.Enterprise.DistributorEnterprise;
import Business.Enterprise.Enterprise;
import Business.Enterprise.HosEnterprise;
import Business.Enterprise.ManufacturerEnterprise;
import Business.Enterprise.PHDEnterprise;
import Business.Enterprise.PharmacyEnterprise;
import Business.Enterprise.StateCenterEnterprise;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.CDCStaffWorkArea.CDCStaffWorkAreaJPanel;
import UserInterface.ClinicStaffWorkArea.ClinicStaffWorkAreaJPanel;
import UserInterface.DistributorStaffWorkArea.DistributorStaffWorkAreaJPanel;
import UserInterface.HosStaffWorkArea.HosStaffWorkAreaJPanel;
import UserInterface.ManufacturerStaffWorkArea.ManufacturerStaffWorkAreaJPanel;
import UserInterface.PHDStaffWorkArea.PHDStaffWorkAreaJPanel;
import UserInterface.PharmacyStaffWorkArea.PharmacyStaffWorkAreaJPanel;
import UserInterface.StateCenterStaffWorkArea.StateCenterStaffWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author wuyan
 */
public class StaffRole extends Role {  
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, Network network, EcoSystem system) {
        JPanel staff = new JPanel();
        
        if(enterprise instanceof CDCEnterprise){
            staff = new CDCStaffWorkAreaJPanel(userProcessContainer, account, enterprise, network);
        }
        else if(enterprise instanceof PHDEnterprise){
            staff = new PHDStaffWorkAreaJPanel(userProcessContainer, account, enterprise, network);
        }
        else if(enterprise instanceof DistributorEnterprise){
            staff = new DistributorStaffWorkAreaJPanel(userProcessContainer, account, enterprise, network);
        }
        else if(enterprise instanceof ManufacturerEnterprise){
            staff = new ManufacturerStaffWorkAreaJPanel(userProcessContainer, enterprise, network);
        }
        else if(enterprise instanceof StateCenterEnterprise){
            staff = new StateCenterStaffWorkAreaJPanel(userProcessContainer, account, enterprise, network);
        }
        else if(enterprise instanceof HosEnterprise){
            staff = new HosStaffWorkAreaJPanel(userProcessContainer, account, enterprise, network);
        }
        else if(enterprise instanceof ClinicEnterprise){
            staff = new ClinicStaffWorkAreaJPanel(userProcessContainer, account, enterprise, network);
        }
        else if(enterprise instanceof PharmacyEnterprise){
            staff = new PharmacyStaffWorkAreaJPanel(userProcessContainer, account, enterprise, network);
        }
        return staff;
    }
}
