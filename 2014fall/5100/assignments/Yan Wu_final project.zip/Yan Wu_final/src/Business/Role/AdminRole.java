/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.CDCEnterprise;
import Business.Enterprise.ClinicEnterprise;
import Business.Enterprise.DistributorEnterprise;
import Business.Enterprise.Enterprise;
import Business.Enterprise.HosEnterprise;
import Business.Enterprise.ManufacturerEnterprise;
import Business.Enterprise.PHDEnterprise;
import Business.Enterprise.PharmacyEnterprise;
import Business.Enterprise.StateCenterEnterprise;
import Business.Network.Network;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import UserInterface.ManufacturerAdminWorkArea.ManufacturerAdminWorkAreaJPanel;
import UserInterface.CDCAdminWorkArea.CDCAdminWorkAreaJPanel;
import UserInterface.ClinicAdminWorkArea.ClinicAdminWorkAreaJPanel;
import UserInterface.DistributorAdminWorkArea.DistributorAdminWorkAreaJPanel;
import UserInterface.HosAdminWorkArea.HosAdminWorkAreaJPanel;
import UserInterface.PHDAdminWorkArea.PHDAdminWorkAreaJPanel;
import UserInterface.PharmacyAdminWorkArea.PharmacyAdminWorkAreaJPanel;
import UserInterface.StateCenterAdminWorkArea.StateCenterAdminWorkAreaJPanel;
import javax.swing.JPanel;

/**
 *
 * @author raunak
 */
public class AdminRole extends Role{

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise, Network network, EcoSystem business) {
        JPanel admin = new JPanel();
        if(enterprise instanceof CDCEnterprise){
            admin = new CDCAdminWorkAreaJPanel(userProcessContainer, enterprise, network);
        }
        else if(enterprise instanceof PHDEnterprise){
            admin = new PHDAdminWorkAreaJPanel(userProcessContainer, enterprise, network);
        }
        else if(enterprise instanceof DistributorEnterprise){
            admin = new DistributorAdminWorkAreaJPanel(userProcessContainer, enterprise, network);
        }
        else if(enterprise instanceof ManufacturerEnterprise){
            admin = new ManufacturerAdminWorkAreaJPanel(userProcessContainer, enterprise, network);
        }
        else if(enterprise instanceof StateCenterEnterprise){
            admin = new StateCenterAdminWorkAreaJPanel(userProcessContainer, enterprise, network);
        }
        else if(enterprise instanceof HosEnterprise){
            admin = new HosAdminWorkAreaJPanel(userProcessContainer, enterprise, network);
        }
        else if(enterprise instanceof ClinicEnterprise){
            admin = new ClinicAdminWorkAreaJPanel(userProcessContainer, enterprise, network);
        }
        else if(enterprise instanceof PharmacyEnterprise){
            admin = new PharmacyAdminWorkAreaJPanel(userProcessContainer, enterprise, network);
        }
        return admin;
    }
    
    
}
