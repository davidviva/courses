/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Inventory;

import Business.Product.Product;
import Business.Product.ProductCatalog;
import Business.Vaccine.Vaccine;


/**
 *
 * @author wuyan
 */
public class InventoryItem {
    private String productor;
    private Vaccine vaccine;
    private int availability = 0;
    private ProductCatalog itemCatalog;
    private int price;
    
    public InventoryItem(){
        itemCatalog = new ProductCatalog();
        vaccine = new Vaccine();
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Vaccine getVaccine() {
        return vaccine;
    }

    public void setVaccine(Vaccine vaccine) {
        this.vaccine = vaccine;
    }

    public String getProductor() {
        return productor;
    }

    public void setProductor(String productor) {
        this.productor = productor;
    }

    public int getAvailability() {
        return availability;
    }

    public void setAvailability(int availability) {
        this.availability = availability;
    }

    public ProductCatalog getItemCatalog() {
        return itemCatalog;
    }

    public void setItemCatalog(ProductCatalog itemCatalog) {
        this.itemCatalog = itemCatalog;
    }
    
    public Product addItem() {
        Product i = new Product();
        itemCatalog.getProductList().add(i);
        return i;
    }
    
    public void removeItem(Product p) {
        itemCatalog.getProductList().remove(p);
    }
    
    public Product searchProduct(int id) {
        for(Product p : itemCatalog.getProductList()) {
            if(p.getProductId() == id) {
                return p;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return vaccine.getVaccineName();
    } 
    
}
