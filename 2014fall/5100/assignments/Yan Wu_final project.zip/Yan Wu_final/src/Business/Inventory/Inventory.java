/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Inventory;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class Inventory {
    ArrayList<InventoryItem> inventory;
    
    public Inventory(){
        inventory = new ArrayList<>();
    }

    public ArrayList<InventoryItem> getInventory() {
        return inventory;
    }

    public void setInventory(ArrayList<InventoryItem> inventory) {
        this.inventory = inventory;
    }
    
    public InventoryItem addItem() {
        InventoryItem i = new InventoryItem();
        inventory.add(i);
        return i;
    }
    
    public InventoryItem addItem(InventoryItem i, int quantity) {
        inventory.add(i);
        i.setAvailability(quantity);
        return i;
    }
    
    public void removeItem(InventoryItem i) {
        inventory.remove(i);
    }
    
    public InventoryItem searchItem(String name) {
        for(InventoryItem i : inventory) {
            if(i.getVaccine().getVaccineName().equalsIgnoreCase(name)) {
                return i;
            }
        }
        return null;
    }
}
