/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Network;

import Business.Disease.DiseaseCatalog;
import Business.Enterprise.EnterpriseDirectory;
import Business.Patient.PatientCatalog;
import Business.Vaccine.VaccineCatalog;
import java.util.ArrayList;

/**
 *
 * @author raunak
 */
public class Network {
    
    private String name;
    private EnterpriseDirectory enterpriseDirectory;
    private VaccineCatalog vaccineCatalog;
    private DiseaseCatalog diseaseCatalog;
    private PatientCatalog patientCatalog;
    private ArrayList<String> advertiseEventDirectory;
    

    public Network() {
        enterpriseDirectory = new EnterpriseDirectory();
        vaccineCatalog = new VaccineCatalog();
        diseaseCatalog = new DiseaseCatalog();
        patientCatalog = new PatientCatalog();
        advertiseEventDirectory = new ArrayList<>();
    }

    public ArrayList<String> getAdvertiseEventDirectory() {
        return advertiseEventDirectory;
    }

    public void setAdvertiseEventDirectory(ArrayList<String> advertiseEventDirectory) {
        this.advertiseEventDirectory = advertiseEventDirectory;
    }
    
    public EnterpriseDirectory getEnterpriseDirectory() {
        return enterpriseDirectory;
    }

    public DiseaseCatalog getDiseaseCatalog() {
        return diseaseCatalog;
    }

    public void setDiseaseCatalog(DiseaseCatalog diseaseCatalog) {
        this.diseaseCatalog = diseaseCatalog;
    }

    public PatientCatalog getPatientCatalog() {
        return patientCatalog;
    }

    public void setPatientCatalog(PatientCatalog patientCatalog) {
        this.patientCatalog = patientCatalog;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public VaccineCatalog getVaccineCatalog() {
        return vaccineCatalog;
    }

    public void setVaccineCatalog(VaccineCatalog vaccineCatalog) {
        this.vaccineCatalog = vaccineCatalog;
    }
    
    @Override
    public String toString() {
        return name;
    }
    
}
