/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Network;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class NetworkDirectory {
    private ArrayList<Network> networkList;
    
    public NetworkDirectory(){
        networkList = new ArrayList<>();
    }

    public ArrayList<Network> getNetworkList() {
        return networkList;
    }

    public void setNetworkList(ArrayList<Network> networkList) {
        this.networkList = networkList;
    }
    
    public Network createAndAddNetwork() {
        Network network = new Network();
        networkList.add(network);
        return network;
    }
    
    public Network searchNetwork(String name){
        for(Network network: networkList){
            if(network.getName().equalsIgnoreCase(name)){
                return network;
            }
        }
        return null;
    }
    
    public void removeNetwork(Network network){
        networkList.remove(network);
    }
}
