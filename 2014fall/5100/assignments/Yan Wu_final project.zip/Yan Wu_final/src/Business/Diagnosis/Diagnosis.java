/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Diagnosis;

import Business.Order.Order;
import Business.VitalSign.VitalSign;
import java.util.Date;

/**
 *
 * @author wuyan
 */
public class Diagnosis {
    private int patientId;
    private VitalSign vitalSign;
    private String primaryDoctorName;
    private Order prescription;
    private int age;
    private char ageGroup;
    private Date timestamp;
    private String advertiseEvent;

    public String getAdvertiseEvent() {
        return advertiseEvent;
    }

    public void setAdvertiseEvent(String advertiseEvent) {
        this.advertiseEvent = advertiseEvent;
    }

    public Diagnosis(){
        vitalSign = new VitalSign();
        prescription = new Order();
        timestamp = new Date();
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }
    
    public VitalSign getVitalSign() {
        return vitalSign;
    }

    public void setVitalSign(VitalSign vitalSign) {
        this.vitalSign = vitalSign;
    }

    public String getPrimaryDoctorName() {
        return primaryDoctorName;
    }

    public void setPrimaryDoctorName(String primaryDoctorName) {
        this.primaryDoctorName = primaryDoctorName;
    }

    public Order getPrescription() {
        return prescription;
    }

    public void setPrescription(Order prescription) {
        this.prescription = prescription;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
  
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(char ageGroup) {
        this.ageGroup = ageGroup;
    }

    @Override
    public String toString() {
        return timestamp.toString();
    }
    
    
}
