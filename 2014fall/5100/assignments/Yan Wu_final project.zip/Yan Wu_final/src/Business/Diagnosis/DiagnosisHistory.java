/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Diagnosis;

import Business.VitalSign.VitalSign;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class DiagnosisHistory {
    ArrayList<Diagnosis> diagnosisList;
    
    public DiagnosisHistory(){
        diagnosisList = new ArrayList<>();
    }

    public ArrayList<Diagnosis> getDiagnosisList() {
        return diagnosisList;
    }

    public void setDiagnosisList(ArrayList<Diagnosis> diagnosisList) {
        this.diagnosisList = diagnosisList;
    }
    
    public Diagnosis addDiagnosis() {
        Diagnosis diagnosis = new Diagnosis();
        diagnosisList.add(diagnosis);
        return diagnosis;
    }
    public void removeDiagnosis(Diagnosis diagnosis) {
        diagnosisList.remove(diagnosis);
    }
}
