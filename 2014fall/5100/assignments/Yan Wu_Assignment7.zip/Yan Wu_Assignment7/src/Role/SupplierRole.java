/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Role;


import UserInterface.SupplierRole.SupplierWorkAreaJPanel;
import javax.swing.JPanel;
import Business.Business;
import Organization.Organization;
import Organization.SupplierOrganization;
import UserAccount.UserAccount;

/**
 *
 * @author wuyan
 */
public class SupplierRole extends Roles {

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer,UserAccount userAccount,Business business,Organization organization) {
     return new SupplierWorkAreaJPanel(userProcessContainer, business, userAccount,(SupplierOrganization)organization);
    }
    
}
