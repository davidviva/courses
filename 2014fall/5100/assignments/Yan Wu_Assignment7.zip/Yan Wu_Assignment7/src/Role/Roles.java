/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Role;

import javax.swing.JPanel;
import Business.Business;
import Organization.Organization;
import UserAccount.UserAccount;

/**
 *
 * @author wuyan
 */
public abstract class Roles {
    
    private String name;
    //public static String name1;
    
    public enum RoleType{
        ADMINROLE("Admin Role"),
        SUPPLIERROLE("Supplier Role"),
        CUSTOMERROLE("Customer Role");
        
        private final String value;
        private RoleType(final String name){
        this.value = name;
        }
        
        public String getValue(){
            
        return value;
        
        
        }

        
    }
    
    public abstract JPanel createWorkArea(JPanel userProcessContainer,UserAccount userAccount,Business business,Organization organization);

    public Roles(){
   
    }
    
    
    @Override
    public String toString() {
        
        return this.getClass().getName();

    }
    
    
}
