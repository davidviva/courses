/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Organization;


import java.util.ArrayList;
import Role.CustomerRole;
import Role.Roles;

/**
 *
 * @author wuyan
 */
public class CustomerOrganization extends Organization{

    public CustomerOrganization(String name) {
        super(Type.CUSTOMER.getValue());
    }

    

    @Override
    public ArrayList<Roles> getSupporttedRole() {
        ArrayList<Roles>role = new ArrayList<>();
       role.add(new CustomerRole());
       return role;
    }
    
}
