/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Organization;


import java.util.ArrayList;
import Person.PersonDirectory;
import Role.Roles;
import UserAccount.UserAccountDirectory;

/**
 *
 * @author wuyan
 */
public abstract class Organization {
    
    private String name;
    //private CustomerDirectory customerDirectory;
    //private SupplierDirectory supplierDirectory;
    private PersonDirectory personDirectory;
    private UserAccountDirectory userAccountDirectory;
    private int id;
    private static int counter = 1;
    
    public enum Type{
        ADMIN("Admin Organization"),
        SUPPLIER("Supplier Organization"),
        CUSTOMER("Customer Organization");
        
        private String value;
        private Type(String name){
        this.value = name;
        }
        public String getValue(){
        return value;
                }

        @Override
        public String toString() {
            return value;
        }
    }
    public abstract ArrayList<Roles> getSupporttedRole();
    
    public Organization(String name){
        this.name = name;
        personDirectory = new PersonDirectory();
        
        userAccountDirectory = new UserAccountDirectory();
        id = counter;
        counter++;   
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    public PersonDirectory getPersonDirectory() {
        return personDirectory;
    }
    
    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return name ;
    }
    
    
    
}
