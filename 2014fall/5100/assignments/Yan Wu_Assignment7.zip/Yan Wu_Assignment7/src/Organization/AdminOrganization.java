/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Organization;


import java.util.ArrayList;
import Role.AdminRole;
import Role.Roles;

/**
 *
 * @author wuyan
 */
public class AdminOrganization extends Organization{

    public AdminOrganization(String name) {
        super(Type.ADMIN.getValue());
    }

    @Override
    public ArrayList<Roles> getSupporttedRole() {
       ArrayList<Roles>role = new ArrayList<>();
       role.add(new AdminRole());
       return role;
    }
    
    
    
}
