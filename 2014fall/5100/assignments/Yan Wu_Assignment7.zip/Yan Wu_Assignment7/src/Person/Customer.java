/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Person;

import Order.MasterOrderCatalog;
import Person.Person;

/**
 *
 * @author wuyan
 */
public class Customer extends Person{
    
    private MasterOrderCatalog masterOrderCatalog;
    
    public Customer(){
        masterOrderCatalog = new MasterOrderCatalog();
    }


    public MasterOrderCatalog getMasterOrderCatalog() {
        return masterOrderCatalog;
    }

    public void setMasterOrderCatalog(MasterOrderCatalog masterOrderCatalog) {
        this.masterOrderCatalog = masterOrderCatalog;
    }


    @Override
    public String toString() {
        return super.getName();
    }
    
    
    
}
