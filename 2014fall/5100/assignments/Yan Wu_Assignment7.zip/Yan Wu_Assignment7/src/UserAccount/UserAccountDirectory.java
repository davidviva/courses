/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package UserAccount;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class UserAccountDirectory {
    private ArrayList <UserAccount> userAccountList;
    
    public UserAccountDirectory(){
        userAccountList = new ArrayList<>();
    }

    public ArrayList<UserAccount> getUserAccountList() {
        return userAccountList;
    }

    public void setUserAccountList(ArrayList<UserAccount> userAccountList) {
        this.userAccountList = userAccountList;
    }
    
    public UserAccount addUserAccount(){
    UserAccount userAccount = new UserAccount();
    userAccountList.add(userAccount);
    return userAccount;
    }
    
    public UserAccount authenticateUser(String username, String password){
        for(UserAccount ua : userAccountList){
        if(ua.getUserName().equals(username)&&ua.getPassWord().equals(password)){
        return ua;
        }
        }
        return null;
    }
    
    public void removeUserAccount(UserAccount ua){
        userAccountList.remove(ua);
    }
    
}
