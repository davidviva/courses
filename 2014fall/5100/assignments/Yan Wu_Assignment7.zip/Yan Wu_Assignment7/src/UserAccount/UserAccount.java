/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package UserAccount;

import Person.Person;
import Role.Roles;

/**
 *
 * @author wuyan
 */
public class UserAccount {
    private String userName;
    private String passWord;
    private String status;
    private Roles role;
    private Person person;
    
    public static final String admin = "Admin";
    public static final String supplier = "Supplier";
    public static final String customer = "Customer";

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Roles getRole() {
        return role;
    }

    public void setRole(Roles role) {
        this.role = role;
    }

    

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    @Override
    public String toString() {
        return userName;
    }
    
    
    
    
}
