/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Order;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class Order {
    private ArrayList<OrderItem> order;
    private static int count;
    private int orderId;
    private String date;
    
    
    public Order()
    {
        count++;
        orderId = count;
    order = new ArrayList<OrderItem>();
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
    
    

    public ArrayList<OrderItem> getOrder() {
        return order;
    }

    public void setOrder(ArrayList<OrderItem> order) {
        this.order = order;
    }

    
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
    
    
    public OrderItem addOrderItem(){
    OrderItem oi = new OrderItem();
    order.add(oi);
    return oi;
    }
    public void removeOrderItem(OrderItem oi){
    order.remove(oi);
    }

    @Override
    public String toString() {
        return String.valueOf(orderId);
    }
    
    
}
