/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Product;

/**
 *
 * @author wuyan
 */
public class Product {
    private static int count = 0;
    private String prodName;
    private int price;
    private int modelNumber;
    
    private int availablity;
    
    private int initialAmount;

    public Product() {
        count++;
        modelNumber = count;
    }

    public int getAvailablity() {
        return availablity;
    }

    public void setAvailablity(int availablity) {
        this.availablity = availablity;
    }
    
    
    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getModelNumber() {
        return modelNumber;
    }

    public int getInitialAmount() {
        return initialAmount;
    }

    public void setInitialAmount(int initialAmount) {
        this.initialAmount = initialAmount;
    }
    
    
    
    @Override
    public String toString() {
        return prodName;
    }
    
}
