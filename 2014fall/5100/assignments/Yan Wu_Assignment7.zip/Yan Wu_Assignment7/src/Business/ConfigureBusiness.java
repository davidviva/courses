/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import Person.Person;
import Organization.AdminOrganization;
import Organization.Organization.Type;
import Role.AdminRole;
import UserAccount.UserAccount;

/**
 *
 * @author wuyan
 */
public class ConfigureBusiness {
    
    public static Business Initialized(){
        Business business = Business.getInstance();
        AdminOrganization aor = new AdminOrganization(Type.ADMIN.getValue());
        business.getOrganizationDirectory().getOrganizationList().add(aor);
        
        Person p = new Person();
        p.setName("chen");
        
        UserAccount ua = new UserAccount();
        ua.setPerson(p);
        ua.setRole(new AdminRole());
        ua.setStatus("Active");
        ua.setUserName("admin");
        ua.setPassWord("admin");
        
        aor.getPersonDirectory().getPersonList().add(p);
        aor.getUserAccountDirectory().getUserAccountList().add(ua);
        
        return business;
    }
    
}
