/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author wuyan
 */
public class Supplier extends Person{
    private String supplyName;
    private String password = "admin" ;
    private ProductCatalog productCatalog ;
    private String organisation;

    public String getOrganisation() {
        return organisation;
    }

    public void setOrganisation(String organisation) {
        this.organisation = organisation;
    }
    
    public Supplier()
    {
        productCatalog = new ProductCatalog() ;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
  
    public String getSupplyName() {
        return super.getFirstName() + " " + super.getLastName();
    }
    
    public void setSupplyName(String s) {
        this.supplyName = s;
    }

    public ProductCatalog getProductCatalog() {
        return productCatalog; 
    }

    public String toString(){
        return super.getFirstName() + super.getLastName();
    } 
    
}
