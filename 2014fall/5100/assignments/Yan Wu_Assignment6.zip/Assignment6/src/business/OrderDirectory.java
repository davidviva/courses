/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class OrderDirectory {
    private ArrayList<Order> orderDirectory;
    public static int count = 0;

    public OrderDirectory() {
        orderDirectory = new ArrayList<Order>();
    }

    public ArrayList<Order> getOrderDirectory() {
        return orderDirectory;
    }

    public void setOrderDirectory(ArrayList<Order> orderDirectory) {
        this.orderDirectory = orderDirectory;
    }
    
   /* public void removeOrder(Order order) {
        orderDirectory.remove(order);
    }
    
    public Order searchOrder(String keyword) {
        for(Order o: orderDirectory) {
            if(keyword.equals(String.valueOf(o.getOrderId()))) {
                return o;
            }
        }
        return null;
    } */
    
    public void addOrder(Order order)
    {
        orderDirectory.add(order);
        count++;
    }
    
    public void removeOrder(Order order){
        orderDirectory.remove(order);
    }
}
