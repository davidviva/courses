/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author wuyan
 */
public class Business {
    public static Business business;
    SupplierDirectory supplierDirectory ;
    CustomerDirectory customerDirectory ;
    private UserAccountDirectory userAccountDirectory;
    
    public Business()
    {
        supplierDirectory = new SupplierDirectory() ;
        customerDirectory = new CustomerDirectory();
        userAccountDirectory = new UserAccountDirectory();
    }
    
    public static Business getInstance(){
        if(business == null){
            business = new Business();
        }
        return business;
    }

    public SupplierDirectory getSupplierDirectory() {
        return supplierDirectory;
    }

    public void setSupplierDirectory(SupplierDirectory supplierDirectory) {
        this.supplierDirectory = supplierDirectory;
    }

    public CustomerDirectory getCustomerDirectory() {
        return customerDirectory;
    }

    public void setCustomerDirectory(CustomerDirectory customerDirectory) {
        this.customerDirectory = customerDirectory;
    }
    
    public UserAccountDirectory getUserAccountDirectory() {
        return userAccountDirectory;
    }

    public void setUserAccountDirectory(UserAccountDirectory userAccountDirectory) {
        this.userAccountDirectory = userAccountDirectory;
    }
}
