/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author wuyan
 */
public class Customer extends Person{
    private int customerId;
    private String customerName;
    private String password = "admin";
    private OrderDirectory orderDirectory;
    private static int customerCount = 0;
    
    public Customer() {
        orderDirectory = new OrderDirectory();
        customerCount++;
        customerId = customerCount;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return super.getFirstName() + " " + super.getLastName();
    }
    
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public OrderDirectory getOrderDirectory() {
        return orderDirectory;
    }

    public String toString(){
        return super.getFirstName() + super.getLastName();
    }   
}
