/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author wuyan
 */
public class Product {
    private static int productCount = 0;
    private int soldNum = 0;
    private int soldAmount = 0;
    private String productName;
    private int price;
    private int availability;
    private int productId;
    
    public Product() {
        productCount++;
        productId = productCount;
    }

    public void setSoldNum(int soldNum) {
        this.soldNum = soldNum;
    }

    public int getSoldNum() {
        return soldNum;
    }

    public int getSoldAmount() {
        return soldAmount;
    }

    public void setSoldAmount(int soldAmount) {
        this.soldAmount = soldAmount;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getAvailability() {
        return availability;
    }

    public void setAvailability(int availability) {
        this.availability = availability;
    }

    public int getProductId() {
        return productId;
    }

    @Override
    public String toString() {
        return productName;
    }
}
