/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author wuyan
 */
public class Administrator extends Person{
    public static Administrator administrator;
    
    public static Administrator getInstance(){
        if(administrator == null){
            administrator = new Administrator();
        }
        return administrator;
    }
    
}
