/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

/**
 *
 * @author wuyan
 */
public class Address {
    
    private String streetName ;
    private String town ;
    private String state ;
    private String country ;
    private String zipcode ;
    private String total ;
    

    /**
     *
     * @return
     */
    
    public String getStreetName() {
    return streetName;
    }
    
    public void setStreetName(String streetName) {
    this.streetName = streetName;
    }
    
    public String getTown() {
    return town;
    }
    
    public void setTown(String town) {
    this.town = town;
    }
    
    public String getState() {
    return state;
    }
    
    public void setState(String state) {
    this.state = state;
    }
    
    public String getCountry() {
    return country;
    }
    
    public void setCountry(String country) {
    this.country = country;
    }
    
    public String getZipCode() {
    return zipcode;
    }
    
    public void setZipCode(String zipcode) {
    this.zipcode = zipcode;
    }

    public String getTotal() {
        return total;
    } 
    
    public void setTotal(String total) {
        this.total = total ; 
    }
       
}
