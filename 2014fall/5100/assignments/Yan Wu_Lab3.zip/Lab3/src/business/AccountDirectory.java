/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class AccountDirectory {
    private ArrayList<Account> accountList;

    // constructor
    public AccountDirectory() {    
        //this.accountList = accountList;
        accountList = new ArrayList<Account>();
    }   

    //getter and setter
    public ArrayList<Account> getAccountList() {
        return accountList;
    }

    public void setAccountList(ArrayList<Account> accountList) {
        this.accountList = accountList;
    }
    
    //functionality   CRUD
    public Account createAccount() {
        Account a = new Account();
        accountList.add(a);
        return a;
    }
    
    public void deleteAccount(Account a) {
        accountList.remove(a);
    }
           
    public Account searchAccount(String accountNum) {
        for(Account a:accountList)
        {
            if(a.getAccountNum().endsWith(accountNum))
            {
                return a;
            }
        }
        return null;
    }
}
