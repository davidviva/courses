/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

/**
 *
 * @author wuyan
 */
public class Product {
    
    private String name ;
    private String desc ;
    private String avail ;
    private String price ;
    
    public String getName() {
        return name ;
    }
    
    public void setName( String name ) {
        this.name = name ;
    }

    public String getDesc() {
        return desc ;
    }

    public void setDesc(String desc) {
        this.desc = desc ;
    }

    public String getAvail() {
        return avail ;
    }

    public void setAvail(String avail) {
        this.avail = avail ;
    }

    public String getPrice() {
        return price ;
    }

    public void setPrice(String price) {
        this.price = price ;
    }  
    
}
