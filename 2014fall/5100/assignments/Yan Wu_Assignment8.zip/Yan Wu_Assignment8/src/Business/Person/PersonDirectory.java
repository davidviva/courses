/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Person;

import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class PersonDirectory {
    private ArrayList<Person> personList;

    
    public PersonDirectory(){
        personList = new ArrayList<>();
    }
    
     public ArrayList<Person> getPersonList() {
        return personList;
    }
     
    public Supplier createSupplier(String name)
    {
        Supplier supplier = new Supplier();
        supplier.setName(name);
        personList.add(supplier);
        return supplier;
    }
    
    public Customer createCustomer(String name)
    {
        Customer customer = new Customer();
        customer.setName(name);
        personList.add(customer);
        return customer;
    }
    
    public SalesSpecialist createSales(String name)
    {
        SalesSpecialist sales=new SalesSpecialist();
        sales.setName(name);
        personList.add(sales);
        return sales;
    }
    
    public ShippingSpecialist createShipping(String name)
    {
        ShippingSpecialist shipping = new ShippingSpecialist();
        shipping.setName(name);
        personList.add(shipping);
        return shipping;
    }
}
