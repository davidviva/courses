/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Person;

import Business.Product.ProductCatalog;

/**
 *
 * @author wuyan
 */
public class Supplier extends Person{
    
    private ProductCatalog productCatalog;
    private String Status;
    
    public Supplier() {
        productCatalog = new ProductCatalog();
    }

    public ProductCatalog getProductCatalog() {
        return productCatalog;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }
   
}
