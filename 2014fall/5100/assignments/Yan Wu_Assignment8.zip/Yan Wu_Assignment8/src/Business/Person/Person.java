/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Person;

/**
 *
 * @author wuyan
 */
public class Person {
    private String name;
    private int personID;
    private static int counter=1;
    
    public Person(){
    personID=counter;
    counter++;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPersonID() {
        return personID;
    }

    public void setPersonID(int personID) {
        this.personID = personID;
    }
    

    @Override
    public String toString()
    {
        return name;
    }
}
