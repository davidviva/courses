/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.WorkQueue;

import Business.Person.Supplier;

/**
 *
 * @author wuyan
 */
public class SupplierEnrollmentWorkRequest extends WorkRequest{
    private String result;
    private Supplier supplier;

    public SupplierEnrollmentWorkRequest(Supplier supplier) {
        this.supplier = supplier;
    }

    
    
    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    @Override
    public String toString()
    {
        return super.getMessage();
    }

    @Override//重写父类的方法，同时设置request和 supplier的status
    public void setStatus(String status) {
        this.status = status;
        supplier.setStatus(status);
    }
    
    
}
