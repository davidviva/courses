/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.WorkQueue;

import Business.Order.Order;

/**
 *
 * @author wuyan
 */
public class ShippingWorkRequest extends WorkRequest{
    private int requestOrderID;
    private String shippingDate;
    private Order order;

    public int getRequestOrderID() {
        return requestOrderID;
    }

    public void setRequestOrderID(int requestOrderID) {
        this.requestOrderID = requestOrderID;
    }

    public String getShippingDate() {
        return shippingDate;
    }

    public void setShippingDate(String shippingDate) {
        this.shippingDate = shippingDate;
    }

    public Order getOrder() {
        return order;
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    @Override
    public String toString()
    {
        return String.valueOf(order.getOrderNumber());
    }
}
