/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import Business.Order.OrderCatalog;
import Business.Organization.OrganizationDirectory;

/**
 *
 * @author wuyan
 */
public class Business {
    private static Business business;
    private OrganizationDirectory organizationDirectory;
    private OrderCatalog orderCatalog;
    
    private Business()
    {
        organizationDirectory = new OrganizationDirectory(); 
        orderCatalog=new OrderCatalog();
    }
    
    public static Business getInstance()
    {
        if(business==null)
        {
            business=new Business();
        }
        return business;
    }

    public static Business getBusiness() {
        return business;
    }

    public static void setBusiness(Business business) {
        Business.business = business;
    }

    public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }

    public OrderCatalog getOrderCatalog() {
        return orderCatalog;
    }

    public void setOrderCatalog(OrderCatalog orderCatalog) {
        this.orderCatalog = orderCatalog;
    }

}
