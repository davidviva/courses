/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Role;

import Business.Business;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;


/**
 *
 * @author wuyan
 */
public abstract class Role{
    
    //RoleType type;
    
    public enum RoleType{
        ADMINROLE("Admin Role"),
        SUPPLIERROLE("Supplier Role"),
        CUSTOMERROLE("Customer Role"),
        SALESROLE("Sales Role"),
        SHIPPINGROLE("Shipping Role");
        
        private final String value;
        private RoleType(final String name){
        this.value = name;
        }
        
        public String getValue(){
            
        return value;
        } 
    }
    
    public abstract JPanel createWorkArea(JPanel userProcessContainer,UserAccount userAccount,Organization organization,Business business);

    
    @Override
    public String toString() {
        
        return this.getClass().getName();

    }
}

