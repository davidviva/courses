/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import Business.Organization.AdminOrganization;
import Business.Organization.Organization.Type;
import Business.Person.Person;
import Business.Role.AdminRole;
import Business.UserAccount.UserAccount;

/**
 *
 * @author wuyan
 */
public class ConfigureBusiness {
    public static Business configure() 
    {
        Business business=Business.getInstance();
        AdminOrganization aor = new AdminOrganization(Type.ADMIN.getValue());
        business.getOrganizationDirectory().getOrganizationList().add(aor);
        
        Person p=new Person();
        p.setName("Admin");
        UserAccount userAccount=new UserAccount();  
        userAccount.setUsername("admin");
        userAccount.setPassword("admin");
        userAccount.setPerson(p);
        userAccount.setRole(new AdminRole());
        userAccount.setIsActive("Active");
        
        aor.getPersonDirectory().getPersonList().add(p);
        aor.getUserAccountDirectory().getUserAccountList().add(userAccount);
        
        return business;
    }
    
    
}
