/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Order;

import Business.Person.Customer;
import Business.Product.Product;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author wuyan
 */
public class Order {
    private ArrayList<OrderItem>orderItemList;
    private int orderNumber;
    private static int count=0;
    private Date timestamp;
    private int totalAmount;
    private Customer customer;
    private String status;
    private String shippingDate;
    
    public Order()
    {
        count++;
        orderNumber=count;
        orderItemList=new ArrayList<>();
       
    }

    public ArrayList<OrderItem> getOrderItemList() {
        return orderItemList;
    }

    public void setOrderItemList(ArrayList<OrderItem> orderItemList) {
        this.orderItemList = orderItemList;
    }

    public int getOrderNumber() {
        return orderNumber;
    }

    public static int getCount() {
        return count;
    }
    
    public static void setCount(int count) {
        Order.count = count;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp() {
        this.timestamp = new Date();
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getShippingDate() {
        return shippingDate;
    }

    public void setShippingDate(String shippingDate) {
        this.shippingDate = shippingDate;
    }
    
    public void removeOrderItem(OrderItem o)
    {
        int avail=o.getProduct().getAvail();
        int newavail=avail+o.getQuantity();
        o.getProduct().setAvail(newavail);
        orderItemList.remove(o);
    }
    
    public OrderItem addOrderItem(Product p, int quantity,int salesPrice)
    {
        OrderItem o= new OrderItem();
        o.setProduct(p);
        o.setQuantity(quantity);
        o.setSalesPrice(salesPrice);
        o.setTotalAmount(quantity,salesPrice);
        orderItemList.add(o);
        return o;
    }
    
    @Override
    public String toString() {
        return String.valueOf(orderNumber);
    }
    
}
