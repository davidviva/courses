/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Product;

/**
 *
 * @author wuyan
 */
public class Product {

    private static int count = 0;
    private String prodName;
    private int price;
    private int modelNumber;
    private int avail;
    private int totalAmount;
    private int soldAmount;
    private int salesAmount;
    private int salesPrice;   

    public Product() {
        count++;
        modelNumber = count;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getModelNumber() {
        return modelNumber;
    }

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Product.count = count;
    }

    public int getAvail() {
        return avail;
    }

    public void setAvail(int avail) {
        this.avail = avail;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    public int getSoldAmount() {
        return soldAmount;
    }

    public void setSoldAmount(int avail,int totalAmount) {
        this.avail=avail;
        this.totalAmount=totalAmount;
        this.soldAmount=totalAmount-avail;
    }

    public int getSalesAmount() {
        return salesAmount;
    }

    public void setSalesAmount(int salesAmount) {
        this.salesAmount = salesAmount;
    }

    public int getSalesPrice() {
        return salesPrice;
    }

    public void setSalesPrice(int salesPrice) {
        this.salesPrice = salesPrice;
    }
    
    @Override
    public String toString() {
        return prodName;
    }

}
