/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Organization;


import Business.Role.Role;
import Business.Role.SalesRole;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class SalesOrganization extends Organization{

    public SalesOrganization(String name) {
        super(Type.SALES.getValue());
    }

    @Override
    public ArrayList<Role> getSupporttedRole() {
        ArrayList<Role>role = new ArrayList<>();
        role.add(new SalesRole());
        return role;
    }
    
}
