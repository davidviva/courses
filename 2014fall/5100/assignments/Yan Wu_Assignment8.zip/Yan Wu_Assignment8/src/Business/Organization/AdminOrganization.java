/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Business.Organization;

import Business.Role.AdminRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author wuyan
 */
public class AdminOrganization extends Organization{
    public AdminOrganization(String name) 
    {
        super(Type.ADMIN.getValue());
    }

    @Override
    public ArrayList<Role> getSupporttedRole() {
        ArrayList<Role>role = new ArrayList<>();
        role.add(new AdminRole());
        return role;
    }
    
}
