/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package business;

import java.util.Date;

/**
 *
 * @author wuyan
 */
public class VitalSign {
    private float respiratoryRate;
    private float heartRate;
    private float systolicBloodPressure;
    private float weightInPounds;
    private Date timestamp;
    private Boolean normal = true;

    public VitalSign() {
        timestamp=new Date();
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return timestamp.toString();
    }
    
    public boolean isNormal(VitalSign vitalSign, char ageGroup) {
        switch(ageGroup) {
            case 'T': 
                if(getRespiratoryRate()>30||getRespiratoryRate()<20) {
                    normal = false;
                    break;
                }
                if(getHeartRate()<80||getHeartRate()>130) {
                    normal = false;
                    break;
                }
                if(getSystolicBloodPressure()<80||getSystolicBloodPressure()>110) {
                    normal = false;
                    break;
                }
                if(getWeightInPounds()<22||getWeightInPounds()>31) {
                    normal = false;
                    break;
                }     
                break;
            case 'P':
                if(getRespiratoryRate()>30||getRespiratoryRate()<20) {
                    normal = false;
                    break;
                }
                if(getHeartRate()<80||getHeartRate()>120) {
                    normal = false;
                    break;
                }
                if(getSystolicBloodPressure()<80||getSystolicBloodPressure()>110) {
                    normal = false;
                    break;
                }
                if(getWeightInPounds()<31||getWeightInPounds()>40) {
                    normal = false;
                    break;
                }   
                break;
            case 'S':
                if(getRespiratoryRate()>30||getRespiratoryRate()<20) {
                    normal =false;
                    break;
                }
                if(getHeartRate()<70||getHeartRate()>110) {
                    normal = false;
                    break;
                }
                if(getSystolicBloodPressure()<80||getSystolicBloodPressure()>120) {
                    normal = false;
                    break;
                }
                if(getWeightInPounds()<41||getWeightInPounds()>92) {
                    normal = false;
                    break;
                } 
                break;
            case 'A':
                if(getRespiratoryRate()>20||getRespiratoryRate()<12) {
                    normal = false;
                    break;
                }
                if(getHeartRate()<55||getHeartRate()>105) {
                    normal = false;
                    break;
                }
                if(getSystolicBloodPressure()<110||getSystolicBloodPressure()>120) {
                    normal = false;
                    break;
                }
                if(getWeightInPounds()<110) {
                    normal = false;
                    break;
                }
                break;
            default: 
                break;
        }
        return normal;
    }
    public float getRespiratoryRate() {
        return respiratoryRate;
    }

    public void setRespiratoryRate(float respiratoryRate) {
        this.respiratoryRate = respiratoryRate;
    }

    public float getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(float heartRate) {
        this.heartRate = heartRate;
    }

    public float getSystolicBloodPressure() {
        return systolicBloodPressure;
    }

    public void setSystolicBloodPressure(float systolicBloodPressure) {
        this.systolicBloodPressure = systolicBloodPressure;
    }

    public float getWeightInPounds() {
        return weightInPounds;
    }

    public void setWeightInPounds(float weightInPounds) {
        this.weightInPounds = weightInPounds;
    }

    public Boolean getNormal() {
        return normal;
    }

    public void setNormal(Boolean normal) {
        this.normal = normal;
    }
    
}
