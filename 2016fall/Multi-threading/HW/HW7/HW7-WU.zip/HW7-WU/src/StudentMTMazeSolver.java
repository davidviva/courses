// Author: Yan Wu

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;


/**
 * This file needs to hold your solver to be tested. 
 * You can alter the class to extend any class that extends MazeSolver.
 * It must have a constructor that takes in a Maze.
 * It must have a solve() method that returns the datatype List<Direction>
 *   which will either be a reference to a list of steps to take or will
 *   be null if the maze cannot be solved.
 */

// Main thought: get the number of processors to be the size of executorService
//		use latch and future task to do my solver
public class StudentMTMazeSolver extends SkippingMazeSolver
{
    public StudentMTMazeSolver(Maze maze)
    {
        super(maze);
    }
     
    /*
     * variants: choice stack, stack size
     * pre-condition: countDown latch 
     * post-condition: latch == 0
     * exception: InterruptionException
     */
    private class MySolver implements Callable<List<Direction>>{
    	// define countDown latch
    	// define stack of choice
    	// define size of stack
    	// define choice
    	
    	// MySolver constructor with parameters of choice stack and latch

		@Override
		public List<Direction> call() throws InterruptedException {

			// AWAIT latch
			// TRY 
			// 	WHILE the choice stack is not empty
			// 		Peek the choice stack
			// 		IF the choice is on the border
			//			Pop choice stack
			// 			IF stack size < the given size
			// 				return null
			//			END IF
			//			IF stack is not empty
			//				test the choice's next direction
			// 			END IF
			// 		CONTINUE
			//		END IF
			//		PUSH stack the choice's next move
			//	END WHILE
			// END TRY
			// CATCH found the solution
			// 	WHILE the stack iterator hasNext() 
			//		PUSH the next's first choice into result list
			//	END WHILE
			// 	IF display the maze 
			//		DISPLAY
			//	END IF
			// 	RETURN result list
			// END CATCH
			// RETURN null 	
    }
    
    /*
     * variants: numbers of threads, choice list, 
     * pre-condition: none
     * post-condition: executorService shuts down, latch == 0, the solution path
     * exception: InterruptedException, ExecutionException, found solution exception
     */
    public List<Direction> solve()
    {
        // DEFINE choice stack
        // DEFINE number of threads
        // DEFINE countdown latch
        // DEFINE threadpoll
        // DEFINE result list
        
        // TRY
        // 	PUSH start's first choice into the stack
        //	CREATE mySolver object with stack and latch
        // 	SUBMIT mySolver task into thread pool
        // 	ADD the future task into result list
        // 	WHILE number of threads < given number of threads
        // 		Peek the choice stack
		// 		IF the choice is on the border
		//			Pop choice stack
		//			IF stack is not empty
		//				test the choice's next direction
		// 			END IF
    	//			CONTINUE
    	// 		END IF
    	//		get the follow choice of the current position and direction
    	//		PUSH the follow into the stack
    	//		IF the follow choice's choices > 2
        //			CREATE mySolver object with stack and latch
        // 			SUBMIT mySolver task into thread pool
        // 			ADD the future task into result list
    	//			ADD current number of threads
    	//		END IF
    	//	END WHILE
    	//	START count down the latch
    	//  SHUT down the thread pool
    	//	RETURN not null future tasks' result
    	// END TRY
    	
		// CATCH found the solution
		// 	WHILE the stack iterator hasNext() 
		//		PUSH the next's first choice into result list
		//	END WHILE
		// 	IF display the maze 
		//		DISPLAY
		//	END IF
		// 	RETURN result list
		// END CATCH

		// CATCH InterruptedException
    	//  PRINT the exception
		// END CATCH
    	
		// CATCH ExecutionException
		// 	PRINT the exception
    	// RETURN null
    }
}
