import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

public class Main {
	// Plumbing follows.
    public static void main(String[] args) throws Exception {
        String srcName = "grill.jpg";
        File srcFile = new File(srcName);
        BufferedImage image = ImageIO.read(srcFile);
        
        System.out.println("Source image: " + srcName);
 
        BufferedImage blurredImage1 = ForkBlur.blur1(image);           
        String dstName1 = "parallel-tulips1.jpg";
        File dstFile1 = new File(dstName1);
        ImageIO.write(blurredImage1, "jpg", dstFile1);      
        System.out.println("Output image: " + dstName1);
        System.out.print("\n");
        
        BufferedImage blurredImage2 = ForkBlur.blur2(image);           
        String dstName2 = "parallel-tulips2.jpg";
        File dstFile2 = new File(dstName2);
        ImageIO.write(blurredImage2, "jpg", dstFile2);      
        System.out.println("Output image: " + dstName2);
        System.out.print("\n");
        
        BufferedImage blurredImage3 = ForkBlur.blur3(image);           
        String dstName3 = "parallel-tulips3.jpg";
        File dstFile3 = new File(dstName3);
        ImageIO.write(blurredImage3, "jpg", dstFile3);      
        System.out.println("Output image: " + dstName3);
        System.out.print("\n");
       
        BufferedImage blurredImage = SerialBlur.blur(image);           
        String dstName = "serial-tulips1.jpg";
        File dstFile = new File(dstName);
        ImageIO.write(blurredImage, "jpg", dstFile);      
        System.out.println("Output image: " + dstName);
    }
}
