/**
 * Author: Yan Wu
 */

/*
 * This class is used to manage the cooking items in each machine
 */
import java.util.LinkedList;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.RunnableFuture;

public class MyThreadPool extends ThreadGroup{
    private boolean isClosed = false;
    private LinkedList<Runnable> workQueue;
    private int threadID;
    public MyThreadPool(int poolSize){
        super("MyThreadPool.");
        setDaemon(true);
        workQueue = new LinkedList<Runnable>();
        for(int i = 0;i<poolSize;i++){
            new WorkThread().start();
        }
    }
    
    public synchronized void execute(Runnable task){
        if(isClosed){
            throw new IllegalStateException("连接池已经关闭...");
        }else{
            workQueue.add(task);
            notify();
        }
    }
    
    protected RunnableFuture<FinishedFood> newTaskFor(Callable<FinishedFood> callable) {
        return new FutureTask<FinishedFood>(callable);
    }
    
    public synchronized Future<FinishedFood> submit(Callable<FinishedFood> task){
    	if (task == null) throw new NullPointerException();
        RunnableFuture<FinishedFood> ftask = newTaskFor(task);
        execute(ftask);
        return ftask;
    }
    
    protected synchronized Runnable getTask() throws InterruptedException {
        while(workQueue.size() == 0){
            if(isClosed){
                return null;
            }
            wait();
        }
        return workQueue.removeFirst();
    }
    
    public synchronized void close(){
        if(!isClosed){
            isClosed = true;
            workQueue.clear();
            interrupt();
        }
    }
    
    public void join(){
        synchronized (this) {
            isClosed = true;
            notifyAll();
        }
        Thread[] threads = new Thread[activeCount()];
        int count = enumerate(threads);
        for(int i = 0;i<count;i++){
            try {
                threads[i].join();
            } catch (Exception e) {
            }
        }
    }
    
    class WorkThread extends Thread{
        public WorkThread(){
            super(MyThreadPool.this,"workThread"+(threadID++));
        }
        @Override
        public void run() {
            while(!isInterrupted()){
                Runnable task = null;
                try {
                    // blocking method
                    task = getTask();
                    
                } catch (Exception e) {
                    
                }
                if(task != null){
                    try {
						task.run();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                }else{
                    break;
                }
            }
        }
    }
}
