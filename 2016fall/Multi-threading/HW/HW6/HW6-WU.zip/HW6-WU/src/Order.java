/**
 * Author: Yan Wu
 */

import java.util.List;

public class Order {
	private final List<Food> orderItems; 
    private final int orderNum;   

    public Order(int orderNum, List<Food> orderItems) {
        this.orderNum = orderNum;
        this.orderItems = orderItems;
    }

    public int getOrderNum() {
        return orderNum;
    }

    public List<Food> getOrderItems() {
        return orderItems;
    }
}
