/**
 * Author: Yan Wu
 */

public class Food {
	public final String name;
	public final int cookTimeMS;

	public Food(String name, int cookTimeMS) {
		this.name = name;
		this.cookTimeMS = cookTimeMS;
	}

	public String toString() {
		return name;
	}
}