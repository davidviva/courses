/**
 * Author: Yan Wu
 */

/*
 * This class is used to bound the finished food with its order number.
 */

public class FinishedFood {
    public final Food food;
    public final int orderNum;

    public FinishedFood(Food food, int orderNum) {
        this.food = food;
        this.orderNum = orderNum;
    }
}
