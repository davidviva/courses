/**
 * Author: Yan Wu
 */

/* 
 * This class is used to store orders waiting to be processed
 */

import java.util.ArrayList;
import java.util.LinkedList;

/*
 * This class is used to store orders waiting to be processed, 
 * and notify the customer whose order is finished.
 */
public class OrderQueue {
    private final ArrayList<Customer> customerList;
    private final LinkedList<Order> orderQueue;

    // constructor
    public OrderQueue(ArrayList<Customer> customerList) {
        this.customerList = customerList;
        orderQueue = new LinkedList<Order>();
    }

    // the customers who have a table, place orders into the order queue
    public synchronized void placeOrder(Customer customer) {
        Order order = new Order(customer.getOrderNum(), customer.getOrder());
        orderQueue.offer(order);
    }

    // when the order queue is not empty, send the next order to the cook
    public synchronized Order getNext() {
        if (!orderQueue.isEmpty()) {
            return orderQueue.poll();
        }
        return null;
    }

    // When an order is completed, find 
    public void finishOrder(Order order) {
    	synchronized(customerList) {
	        for (int i = 0; i < customerList.size(); i++) {
	            Customer customer = customerList.get(i);
	            if (customer.getOrderNum() == order.getOrderNum()) {
	                customerList.get(i).receiveOrder(order);
	                customerList.remove(i);
	                break;
	            }
	        }
    	}
    }
}

