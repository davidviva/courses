
// Author: Yan Wu

import java.util.concurrent.atomic.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.ConcurrentLinkedQueue;

@ThreadSafe
public class LockFreeQueue<V> {
	// the queue node
	private class Node<V> {
		public V value = null;
		public AtomicReference<Node<V>> next = null;

		public Node(V value, Node next) {
			this.value = value;
			this.next = new AtomicReference<Node<V>>(next);
		}
	}

	private AtomicReference<Node<V>> head = null; // queue head
	private AtomicReference<Node<V>> tail = null; // queue tail
	private AtomicInteger queueSize = new AtomicInteger(0); // size of the queue

	public LockFreeQueue() {
		Node<V> dummy = new Node<V>(null, null); // init an dummy node
		// init head and tail,reference to the same dummy node
		head = new AtomicReference<Node<V>>(dummy);
		tail = new AtomicReference<Node<V>>(dummy);
	}

	/**
	 * <p>
	 * Add an value to the end of the queue
	 * </p>
	 * <p>
	 * This method is based on CAP operation,and is thread safe.
	 * </p>
	 * <p>
	 * It guarantee the value will eventually add into the queue
	 * </p>
	 * 
	 * @param value
	 *            the value to be added into the queue
	 */
	public void add(V value) {
		Node<V> newNode = new Node<V>(value, null);
		Node<V> oldTail = null;
		while (true) {
			oldTail = tail.get();
			AtomicReference<Node<V>> nextNode = oldTail.next;
			if (nextNode.compareAndSet(null, newNode)) {
				break;
			} else {
				tail.compareAndSet(oldTail, oldTail.next.get());
			}
		}
		queueSize.getAndIncrement();
		tail.compareAndSet(oldTail, oldTail.next.get());
	}

	/**
	 * <p>
	 * Get an Value from the queue
	 * </p>
	 * <p>
	 * This method is based on CAP operation,thread safe
	 * </p>
	 * <p>
	 * It guarantees return an value or null if queue is empty eventually
	 * </p>
	 * 
	 * @return value on the head of the queue,or null when queue is empty
	 */
	public V deQueue() {
		while (true) {
			Node<V> oldHead = head.get();
			Node<V> oldTail = tail.get();
			AtomicReference<Node<V>> next = oldHead.next;
			if (next.get() == null) {
				return null; /// queue is empty
			}
			if (oldHead == tail.get()) {
				tail.compareAndSet(oldTail, oldTail.next.get()); // move the
																	// tail to
																	// last node
				continue;
			}
			if (head.compareAndSet(oldHead, oldHead.next.get())) {
				queueSize.getAndDecrement();
				return oldHead.next.get().value;
			}
		}
	}

	/**
	 * <p>
	 * Get the size of the stack
	 * </p>
	 * <p>
	 * This method doesn't reflect timely state when used in concurrency
	 * environment
	 * </p>
	 * 
	 * @return size of the stack
	 */
	public int size() {
		return queueSize.get();
	}

	/**
	 * <p>
	 * Check if the stack is empty
	 * </p>
	 * <p>
	 * This method doesn't reflect timely state when used in concurrency
	 * environment
	 * </p>
	 * 
	 * @return false unless stack is empty
	 */
	public boolean isEmpty() {
		return queueSize.get() == 0;
	}

	public boolean remove(Object o) {
		if (o == null)
			return false;
		AtomicReference<Node<V>> pred = null;
		for (AtomicReference<Node<V>> p = first(); p != null; p = succ(p)) {
			V item = p.get().value;
			if (item != null && o.equals(item) && p.compareAndSet(p.get(), null)) {
				AtomicReference<Node<V>> next = succ(p);
				if (pred != null && next != null)
					pred.compareAndSet(p.get(), next.get());
				return true;
			}
			pred = p;
		}
		return false;
	}

	AtomicReference<Node<V>> first() {
		restartFromHead: for (;;) {
			for (AtomicReference<Node<V>> h = head, p = h, q;;) {
				boolean hasItem = (p.get().value != null);
				if (hasItem || (q = p.get().next) == null) {
					updateHead(h, p);
					return hasItem ? p : null;
				} else if (p == q)
					continue restartFromHead;
				else
					p = q;
			}
		}
	}
	
    final void updateHead(AtomicReference<Node<V>> h, AtomicReference<Node<V>> p) {
        if (h.get() != p.get() && head.compareAndSet(h.get(), p.get()))
            h.lazySet(h.get());
    }
    
    final AtomicReference<Node<V>> succ(AtomicReference<Node<V>> p) {
    	AtomicReference<Node<V>> next = p.get().next;
        return (p == next) ? head: next;
    }
    
    final Node<V> succ(Node<V> p) {
    	Node<V> next = p.next.get();
        return (p == next) ? head.get(): next;
    }
    
    public boolean contains(Object o) {
        if (o == null) return false;
        for (AtomicReference<Node<V>> p = first(); p != null; p = succ(p)) {
            V item = p.get().value;
            if (item != null && o.equals(item))
                return true;
        }
        return false;
    }
    
    public Iterator<V> iterator() {
        return new Itr();
    }

    private class Itr implements Iterator<V> {
        /**
         * Next node to return item for.
         */
        private AtomicReference<Node<V>> nextNode;

        /**
         * nextItem holds on to item fields because once we claim
         * that an element exists in hasNext(), we must return it in
         * the following next() call even if it was in the process of
         * being removed when hasNext() was called.
         */
        private V nextItem;

        /**
         * Node of the last returned item, to support remove.
         */
        private AtomicReference<Node<V>> lastRet;

        Itr() {
            advance();
        }

        /**
         * Moves to next valid node and returns item to return for
         * next(), or null if no such.
         */
        private V advance() {
            lastRet = nextNode;
            V x = nextItem;

            AtomicReference<Node<V>> pred, p;
            if (nextNode == null) {
                p = first();
                pred = null;
            } else {
                pred = nextNode;
                p = succ(nextNode);
            }

            for (;;) {
                if (p == null) {
                    nextNode = null;
                    nextItem = null;
                    return x;
                }
                V item = p.get().value;
                if (item != null) {
                    nextNode = p;
                    nextItem = item;
                    return x;
                } else {
                    // skip over nulls
                	AtomicReference<Node<V>> next = succ(p);
                    if (pred != null && next != null)
                        pred.compareAndSet(p.get(), next.get());
                    p = next;
                }
            }
        }

        public boolean hasNext() {
            return nextNode != null;
        }

        public V next() {
            if (nextNode == null) throw new NoSuchElementException();
            return advance();
        }
    }
    
    public List<V> toList() {
        // Use ArrayList to deal with resizing.
        ArrayList<V> al = new ArrayList<V>();
        for (Node<V> p = first().get(); p != null; p = succ(p)) {
            V item = p.value;
            if (item != null)
                al.add(item);
        }
        return al;
    }
}