

public @interface ThreadSafe {

}
