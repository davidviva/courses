import java.util.*;

/**
 * This class runs <code>numThreads</code> instances of
 * <code>ParallelMaximizerWorker</code> in parallel to find the maximum
 * <code>Integer</code> in a <code>LinkedList</code>.
 */
public class ParallelMaximizer {

    int numThreads;
    ArrayList<ParallelMaximizerWorker> workers; // = new ArrayList<ParallelMaximizerWorker>(numThreads);

    public ParallelMaximizer(int numThreads) {
        this.numThreads = numThreads;
        workers = new ArrayList<ParallelMaximizerWorker>(numThreads);
    }

    public static void main(String[] args) {
        int numThreads = 4; // number of threads for the maximizer
        int numElements = 10; // number of integers in the list

        ParallelMaximizer maximizer = new ParallelMaximizer(numThreads);
        LinkedList<Integer> list = new LinkedList<Integer>();

        // populate the list
        // TODO: change this implementation to test accordingly
        int serialMax = Integer.MIN_VALUE;
        Random rand = new Random();
        for (int i = 0; i < numElements; i++) {
            int next = rand.nextInt();
            list.add(next);
            serialMax = Math.max(serialMax, next);
        }
//        System.out.println(list);
        System.out.println("Single Thread result: " + serialMax);
        // run the maximizer
        try {
            System.out.println("Multi Thread result:  " + maximizer.max(list));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        
        
        // test cases
        System.out.println("Another test case");
        numThreads = 6; // number of threads for the maximizer
        numElements = 100000; // number of integers in the list

        maximizer = new ParallelMaximizer(numThreads);
        list = new LinkedList<Integer>();

        // populate the list
        // TODO: change this implementation to test accordingly
        serialMax = Integer.MIN_VALUE;
        rand = new Random();
        for (int i = 0; i < numElements; i++) {
            int next = rand.nextInt();
            list.add(next);
            serialMax = Math.max(serialMax, next);
        }
//        System.out.println(list);
        System.out.println("Single Thread result: " + serialMax);
        // run the maximizer
        try {
            System.out.println("Multi Thread result:  " + maximizer.max(list));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    /**
     * Finds the maximum by using <code>numThreads</code> instances of
     * <code>ParallelMaximizerWorker</code> to find partial maximums and then
     * combining the results.
     *
     * @param list <code>LinkedList</code> containing <code>Integers</code>
     * @return Maximum element in the <code>LinkedList</code>
     * @throws InterruptedException
     */
    public int max(LinkedList<Integer> list) throws InterruptedException {
        int max = Integer.MIN_VALUE; // initialize max as lowest value

//        System.out.println(workers.size());
        System.out.println("Number of threads: " + numThreads);
        
        // run numThreads instances of ParallelMaximizerWorker
        for (int i = 0; i < numThreads; i++) {
//            workers.set(i, new ParallelMaximizerWorker(list)); 
            workers.add(new ParallelMaximizerWorker(list));
            workers.get(i).run();
        }
        // wait for threads to finish
        for (int i = 0; i < numThreads; i++) {
            workers.get(i).join();
        }

        // take the highest of the partial maximums
        // TODO: IMPLEMENT CODE HERE
        for (int i = 0; i < numThreads; i++) {
            max = Math.max(max, workers.get(i).getPartialMax());
        }
        return max;
    }

}
