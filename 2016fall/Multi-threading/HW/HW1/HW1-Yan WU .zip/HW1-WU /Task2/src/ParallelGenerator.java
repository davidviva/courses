
import java.util.*;

/**
 * This class runs <code>numThreads</code> instances of
 * <code>ParallelMaximizerWorker</code> in parallel to find the maximum
 * <code>Integer</code> in a <code>LinkedList</code>.
 */
public class ParallelGenerator {

    int numThreads;
    LinkedList<Integer> resultList;
    ArrayList<ParallelGeneratorWorker> workers; // = new ArrayList<ParallelMaximizerWorker>(numThreads);

    public ParallelGenerator(int numThreads) {
        this.numThreads = numThreads;
        workers = new ArrayList<ParallelGeneratorWorker>(numThreads);
        resultList = new LinkedList<Integer>();
    }

    public static void main(String[] args) {
        int numThreads = 4; // number of threads for the maximizer
        int numElements = 3; // number of integers in each list

        System.out.println("Number of threads: " + numThreads);
        System.out.println("Number of elements in each list: " + numElements);
        
        ParallelGenerator generator = new ParallelGenerator(numThreads);

        // multi-thread sort
        try {
        	System.out.println("Multi threads:");
            System.out.println(generator.sort(numElements));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // serial sort
        int[] array = new int[numElements * numThreads];
        int count = 0;
        for (int i = 0; i < numThreads; i++) {
        	LinkedList<Integer> sublist = generator.workers.get(i).getList();
        	for(int j = 0; j < sublist.size(); j++) {
        		array[count++] = sublist.get(j);
        	}
        }
        Arrays.sort(array);
        System.out.println("Serial sort: ");
        for (int i : array) {
        	System.out.print(i + ", ");
        }
    }

    /**
     * Finds the maximum by using <code>numThreads</code> instances of
     * <code>ParallelMaximizerWorker</code> to find partial maximums and then
     * combining the results.
     *
     * @param list <code>LinkedList</code> containing <code>Integers</code>
     * @return Maximum element in the <code>LinkedList</code>
     * @throws InterruptedException
     */
    public LinkedList<Integer> sort(int numElements) throws InterruptedException {
        
        // run numThreads instances of ParallelMaximizerWorker
        for (int i = 0; i < numThreads; i++) {
//            workers.set(i, new ParallelMaximizerWorker(list)); 
            workers.add(new ParallelGeneratorWorker(numElements, resultList));
            workers.get(i).run();
        }
        // wait for threads to finish
        for (int i = 0; i < numThreads; i++) {
            workers.get(i).join();
        }

        return resultList;
    }

}

