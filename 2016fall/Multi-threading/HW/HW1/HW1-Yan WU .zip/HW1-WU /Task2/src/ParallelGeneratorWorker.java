
import java.util.LinkedList;
import java.util.Random;

/**
 * Given a <code>LinkedList</code>, this class will find the maximum over a
 * subset of its <code>Integers</code>.
 */
public class ParallelGeneratorWorker extends Thread {

    protected LinkedList<Integer> list;
    protected LinkedList<Integer> resultList;
    protected int numElements;

    public ParallelGeneratorWorker(int numElements, LinkedList<Integer> resultList) {
        this.numElements = numElements;
        list = new LinkedList<Integer>();
        this.resultList = resultList;
    }

    /**
     * Update <code>partialMax</code> until the list is exhausted.
     */
    public void run() {
        // generate the random lsit
        Random rand = new Random();
        for (int i = 0; i < numElements; i++) {
            int next = rand.nextInt();
            list.add(next);
        }
        
        int count = 0;
        while (true) {
            synchronized (resultList) {
                if (count == list.size()) {
                    return;
                }
                int num = list.get(count++);

                if (resultList.size() == 0) {
                    resultList.add(num);
                } else {
                    // find the position
                    int i;
                    for (i = 0; i < resultList.size(); i++) {
                        if (resultList.get(i) > num) {
                            break;
                        }
                    }
                    resultList.add(i, num);
                }
            }
        }
    }

    public LinkedList<Integer> getList() {
        return list;
    }
}

