
// Author: Yan Wu

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * This file needs to hold your solver to be tested. You can alter the class to
 * extend any class that extends MazeSolver. It must have a constructor that
 * takes in a Maze. It must have a solve() method that returns the datatype List
 * <Direction> which will either be a reference to a list of steps to take or
 * will be null if the maze cannot be solved.
 */

// Main thought: multi-threads DFS, using latch to control

public class StudentMTMazeSolver extends SkippingMazeSolver {
	public StudentMTMazeSolver(Maze maze) {
		super(maze);
	}


	private class DFSworker implements Callable<List<Direction>> {
		private CountDownLatch latch;
		private LinkedList<Choice> stack;
		private final int numChoices;
		private Choice ch;

		public DFSworker(LinkedList<Choice> stack, CountDownLatch latch) {
			this.stack = new LinkedList<Choice>(stack);
			this.numChoices = stack.size();
			this.latch = latch;
		}

		@Override
		public List<Direction> call() throws InterruptedException {
			latch.await();
			try {
				while (!stack.isEmpty()) {
					ch = stack.peek();
					if (ch.isDeadend()) {
						stack.pop();
						if (stack.size() < numChoices) {
							return null;
						}
						if (!stack.isEmpty()) {
							stack.peek().choices.pop();
						}
						continue;
					}
					stack.push(follow(ch.at, ch.choices.peek()));
				}
			} catch (SolutionFound e) {
				
				ListIterator<Choice> it = stack.listIterator();
				LinkedList<Direction> solutionPath = new LinkedList<Direction>();
				while (it.hasNext()) {
					Choice ch = it.next();
					solutionPath.push(ch.choices.peek());
				}

				updateDisplay();
				return pathToFullPath(solutionPath);
			}
			return null;
		}

	}

	// The main body of solver method
	public List<Direction> solve() {
		CountDownLatch startLatch = new CountDownLatch(1);
		ExecutorService workpool = Executors.newFixedThreadPool(3);
		LinkedList<Choice> choiceStack = new LinkedList<>();
		List<Future<List<Direction>>> path = new ArrayList<>();

		try {
			int num = 0;
			Position startPos = maze.getStart();
			choiceStack.push(firstChoice(startPos));
			path.add(workpool.submit(new DFSworker(choiceStack, startLatch)));
			while (num <= 3) {
				Choice choice = choiceStack.peek();
				if (choice.isDeadend()) {
					choiceStack.pop();
					if (!choiceStack.isEmpty())
						choiceStack.peek().choices.pop();
					continue;
				}
				choice = follow(choice.at, choice.choices.peek());
				choiceStack.push(choice);
				if (choice.choices.size() > 1) {
					path.add(workpool.submit(new DFSworker(new LinkedList<Choice>(choiceStack), startLatch)));
					num++;
				}
			}

			startLatch.countDown();

			workpool.shutdown();
			workpool.awaitTermination(1, TimeUnit.MINUTES);
			int length = path.size();
			for (int index = 0; index < length; index++) {
				Future<List<Direction>> result = path.get(index);
				if (result.get() != null)
					return result.get();
			}

			// No solution found.
		} catch (SolutionFound e) {
			LinkedList<Direction> solutionPath = new LinkedList<Direction>();
			ListIterator<Choice> it = choiceStack.listIterator();
			while (it.hasNext()) {
				Choice choice = it.next();
				solutionPath.push(choice.choices.peek());
			}
			
//			for (Choice choice: choiceStack) {
//				solutionPath.push(choice.choices.peek());
//			}

			updateDisplay();
			return pathToFullPath(solutionPath);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void updateDisplay() {
		if (maze.display != null) {
			maze.display.updateDisplay();
		}
	}
}
