
/**
 *  @author Yan WU
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AuctionServer {
	/**
	 * Singleton: the following code makes the server a Singleton. You should
	 * not edit the code in the following noted section.
	 * 
	 * For test purposes, we made the constructor protected.
	 */

	/**
	 * @Invariant: each bidder offers number of bids for each item < maxBidCount,
	 *             the number of items that each seller offers < maxSellerItems,
	 *             the number of items that all sellers offer < serverCapacity, 
	 *             the number of items that are currently open for bidding < serverCapacity, 
	 *             the current highest bidding price = max(biddingAmount) 
	 *             the bidding price > the item's lowestBiddingPrice
	 */
	
	/* Singleton: Begin code that you SHOULD NOT CHANGE! */
	protected AuctionServer() {
	}

	private static AuctionServer instance = new AuctionServer();

	public static AuctionServer getInstance() {
		return instance;
	}

	/* Singleton: End code that you SHOULD NOT CHANGE! */

	/*
	 * Statistic variables and server constants: Begin code you should likely
	 * leave alone.
	 */

	/**
	 * Server statistic variables and access methods:
	 */
	private int soldItemsCount = 0;
	private int revenue = 0;

	public int soldItemsCount() {
		return this.soldItemsCount;
	}

	public int revenue() {
		return this.revenue;
	}

	/**
	 * Server restriction constants:
	 */
	public static final int maxBidCount = 10; // The maximum number of bids at
												// any given time for a buyer.
	public static final int maxSellerItems = 20; // The maximum number of items
													// that a seller can submit
													// at any given time.
	public static final int serverCapacity = 80; // The maximum number of active
													// items at a given time.

	/*
	 * Statistic variables and server constants: End code you should likely
	 * leave alone.
	 */

	/**
	 * Some variables we think will be of potential use as you implement the
	 * server...
	 */

	// List of items currently up for bidding (will eventually remove things
	// that have expired).
	private List<Item> itemsUpForBidding = new ArrayList<Item>();

	// The last value used as a listing ID. We'll assume the first thing added
	// gets a listing ID of 0.
	private int lastListingID = -1;

	// List of item IDs and actual items. This is a running list with everything
	// ever added to the auction.
	private HashMap<Integer, Item> itemsAndIDs = new HashMap<Integer, Item>();

	// List of itemIDs and the highest bid for each item. This is a running list
	// with everything ever added to the auction.
	private HashMap<Integer, Integer> highestBids = new HashMap<Integer, Integer>();

	// List of itemIDs and the person who made the highest bid for each item.
	// This is a running list with everything ever bid upon.
	private HashMap<Integer, String> highestBidders = new HashMap<Integer, String>();

	// List of sellers and how many items they have currently up for bidding.
	private HashMap<String, Integer> itemsPerSeller = new HashMap<String, Integer>();

	// List of buyers and how many items on which they are currently bidding.
	private HashMap<String, Integer> itemsPerBuyer = new HashMap<String, Integer>();

	// Object used for instance synchronization if you need to do it at some
	// point
	// since as a good practice we don't use synchronized (this) if we are doing
	// internal
	// synchronization.
	//
	// private Object instanceLock = new Object();

	/*
	 * The code from this point forward can and should be changed to correctly
	 * and safely implement the methods as needed to create a working
	 * multi-threaded server for the system. If you need to add Object instances
	 * here to use for locking, place a comment with them saying what they
	 * represent. Note that if they just represent one structure then you should
	 * probably be using that structure's intrinsic lock.
	 */

	/**
	 * Attempt to submit an <code>Item</code> to the auction
	 * 
	 * @param sellerName
	 *            Name of the <code>Seller</code>
	 * @param itemName
	 *            Name of the <code>Item</code>
	 * @param lowestBiddingPrice
	 *            Opening price
	 * @param biddingDurationMs
	 *            Bidding duration in milliseconds
	 * @return A positive, unique listing ID if the <code>Item</code> listed
	 *         successfully, otherwise -1
	 */
	
	/**
	 * Precondition: lowestBidderPrice > 0 and biddingDurationMs > 0, itemsAndIDs, itemsPerSeller, itemsUpForBidding are not null
	 * Postcondition: return lastlistingID when success, or return -1
	 * Exception: Nothing
	 */
	public int submitItem(String sellerName, String itemName, int lowestBiddingPrice, int biddingDurationMs) {
		// TODO: IMPLEMENT CODE HERE
		// Some reminders:
		// Make sure there's room in the auction site.
		// If the seller is a new one, add them to the list of sellers.
		// If the seller has too many items up for bidding, don't let them add
		// this one.
		// Don't forget to increment the number of things the seller has
		// currently listed.

		// PSEUDOCODE: IMPLEMENT CODE HERE

		// AQUIRE LOCK itemsUpForBidding
		// 	IF the number of all submitted items is larger than serverCapacity THEN
		// 		RETURN -1, cannot be added to the server
		// 	END IF
		// 	IF the seller is new THEN
		// 		Add the seller into the list with 0 items
		// 	ELSE IF the seller exceeds the max number of items THEN
		// 		RETURN -1, cannot add more
		// 	END IF
		
		// 	CREATE a new item with the given information
		// 	ADD the newItem to the currently bidding item list
		// 	INCREASE the lastListingID
		// 	UPDATE the number of the seller's items
		// 	ADD the item and listingID to the item list
		// REALSE LOCK itemsUpForBidding
		// RETURN the item listingID 
		
		return -1;
	}

	/**
	 * Get all <code>Items</code> active in the auction
	 * 
	 * @return A copy of the <code>List</code> of <code>Items</code>
	 */
	/**
	 * Precondition: Nothing
	 * PostCondidtion: returns items that are currently bidding
	 * Exception:  Nothing
	 */
	public List<Item> getItems() {
		// TODO: IMPLEMENT CODE HERE
		// Some reminders:
		// Don't forget that whatever you return is now outside of your control.

		// AQUIRE LOCK itemsUpForBidding
		// COPY the list of currently bidding items 
		// RETURN the copied list of currently bidding items 
		// REALSE LOCK itemsUpForBidding
		
		return new ArrayList<Item>();
	}

	/**
	 * Attempt to submit a bid for an <code>Item</code>
	 * 
	 * @param bidderName
	 *            Name of the <code>Bidder</code>
	 * @param listingID
	 *            Unique ID of the <code>Item</code>
	 * @param biddingAmount
	 *            Total amount to bid
	 * @return True if successfully bid, false otherwise
	 */
	
	/**
	 * Precondition: listingID >= 0 and biddingAmount >= 0, itemsPerBuyer, itemsUpForBidding, highestBidder, highestBids are not null
	 * Postcondition: return true when successfully bid, or return false
	 * Exception: Nothing
	 */
	public boolean submitBid(String bidderName, int listingID, int biddingAmount) {
		// TODO: IMPLEMENT CODE HERE
		// Some reminders:
		// See if the item exists.
		// See if it can be bid upon.
		// See if this bidder has too many items in their bidding list.
		// Get current bidding info.
		// See if they already hold the highest bid.
		// See if the new bid isn't better than the existing/opening bid floor.
		// Decrement the former winning bidder's count
		// Put your bid in place
		
		// PSEUDOCODE:
		// IF the item in the item list THEN
		// 		IF the buyer has bided before THEN
		//			IF the buyer is still qualified THEN
		// 				GET the his bidding count
		//			END IF
		// 			IF the buyer exceeds the max bidding times THEN
		//				RETURN false to stop this bid
		//			END IF
		//		END IF
		//		AQUIRE LOCK this
		//			IF the item is currently open for bidding THEN
		//  			IF there's someone bidding THEN
		// 					IF the highest price bidder is the current bidder THEN
		//						RETURN false to stop this bid
		//					END IF
		// 					IF the bidding amount is illegal THEN
		//						RETURN false to stop this bid
		//					END IF
		//				ELSE 
		//					ADD the bid to the highest bid list
		//					ADD the bidder to the highest bidder list
		// 					UPDATE this buyer's bidding record
		//				END IF
		//			END IF
		// 		RELEASE LOCK this
		// END IF

		return false;
	}

	/**
	 * Check the status of a <code>Bidder</code>'s bid on an <code>Item</code>
	 * 
	 * @param bidderName
	 *            Name of <code>Bidder</code>
	 * @param listingID
	 *            Unique ID of the <code>Item</code>
	 * @return 1 (success) if bid is over and this <code>Bidder</code> has won
	 *         <br>
	 *         2 (open) if this <code>Item</code> is still up for auction<br>
	 *         3 (failed) If this <code>Bidder</code> did not win or the
	 *         <code>Item</code> does not exist
	 */
	
	/**
	 * Precondition: itemsAndIDs, itemsPerSeller, higestBids, itemsUpForBidding, itemsPerBuyer are not null, 
	 * 			highest bid price > lowestBiddingPrice, listingID >= 0
	 * Postcondition: return 1 or 2 or 3 to represent different bid status
	 * Exception: Nothing
	 */
	public int checkBidStatus(String bidderName, int listingID) {
		// TODO: IMPLEMENT CODE HERE
		// Some reminders:
		// If the bidding is closed, clean up for that item.
		// Remove item from the list of things up for bidding.
		// Decrease the count of items being bid on by the winning bidder if
		// there was any...
		// Update the number of open bids for this seller

		// PSEUDOCODE:
		// GET the item from the item list by ID
		// GET the seller of the item
		// IF the item doesn't exit THEN
		//		RETURN 3, failed status
		// END IF
		
		// GET the item is open for bidding or not
		// IF the item is still open THEN
		//		RETURN 2, open status
		// ELSE 
		//		AQUIRE LOCK the currently bidding item list (itemUpForBidding)
		//			IF the item is bided THEN 
		// 				INCREASE the number of sold items
		//				COMPUTE the revenue
		//			END IF
		// 			REMOVE the item from the current bidding list
		// 			UPDATE the seller's available items list
		//		RELEASE LOCK the currently bidding item list (itemUpForBidding)
		//		GET the win bidder of the item 
		// 		IF the win bidder is the current bidder THEN
		//			UPDATE the current bidder's bidding record
		//			RETURN 1, success status
		//		ELSE 
		//			UPDATE the win bidder's current bidding item list
		//			RETURN 3, failed status
		// 		END IF
		// END IF
		return -1;
	}

	/**
	 * Check the current bid for an <code>Item</code>
	 * 
	 * @param listingID
	 *            Unique ID of the <code>Item</code>
	 * @return The highest bid so far or the opening price if no bid has been
	 *         made, -1 if no <code>Item</code> exists
	 */
	
	/**
	 * Precondition: itemsUpForBidding, highestBids are not null, listingID >= 0
	 * Postcondition: itemPrice >= items.lowestBiddingPrice
	 * Exception: Nothing
	 */
	public int itemPrice(int listingID) {
		// TODO: IMPLEMENT CODE HERE

		// PSEUDOCODE
		// IF there's bids for the item THEN
		//		RETURN the current highest price
		// ELSE
		//		AQUIRE LOCK the current bidding item list (itemUpForBidding)
		//		IF the item is in in the current bidding item list THEN
		//			RETURN the lowestBiddingPrice
		//		END IF
		// 		RELEASE LOCK the current bidding item list (itemUpForBidding)
		// END IF
		return -1;
	}

	/**
	 * Check whether an <code>Item</code> has been bid upon yet
	 * 
	 * @param listingID
	 *            Unique ID of the <code>Item</code>
	 * @return True if there is no bid or the <code>Item</code> does not exist,
	 *         false otherwise
	 */
	
	/**
	 * Precondition: listingID >= 0, highestBids, itemsAndIDs, itemsUpForBidding are not null
	 * Postcondition: return true or false
	 * Exception: Nothing
	 */
	public Boolean itemUnbid(int listingID) {
		// TODO: IMPLEMENT CODE HERE

		// PSEUDOCODE
		// AQUIRE LOCK this
		// IF the item doesn't exist THEN
		//		RETURN true
		// END IF
		// IF there's bids for the item THEN
		//	 	RETURN false, the item is bided
		// ELSE IF the item is in the current bidding item list THEN 
		//		RETURN true
		// END IF
		// RELEASE LOCK this

		return false;
	}

}
